import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import productBedsheet from "@/assets/product-bedsheet.jpg";
import productQuilt from "@/assets/product-quilt.jpg";
import productMattress from "@/assets/product-mattress.jpg";
import productPillow from "@/assets/product-pillow.jpg";

const Categories = () => {
  const categories = [
    {
      name: "Bedsheets",
      description: "Soft & breathable cotton sheets",
      image: productBedsheet,
      count: "50+ Products",
    },
    {
      name: "Quilts",
      description: "Cozy quilts for every season",
      image: productQuilt,
      count: "30+ Products",
    },
    {
      name: "Mattresses",
      description: "Premium foam mattresses",
      image: productMattress,
      count: "20+ Products",
    },
    {
      name: "Pillows",
      description: "Comfort pillows for better sleep",
      image: productPillow,
      count: "40+ Products",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="about" className="py-20 lg:py-28 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="inline-block px-4 py-1.5 bg-accent/20 text-foreground rounded-full text-sm font-medium mb-4">
            Our Categories
          </span>
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-primary mb-6">
            Explore Our Carefully Selected Range
          </h2>
          <p className="text-lg text-muted-foreground">
            From bedsheets and pillow covers to beds and home décor, crafted to enhance everyday comfort and create a cozy, inviting home.
          </p>
        </motion.div>

        {/* Categories Grid */}
        <motion.div
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {categories.map((category, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="group relative"
            >
              <div className="relative bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-hover transition-all duration-500 cursor-pointer">
                {/* Image Container */}
                <div className="aspect-square overflow-hidden bg-muted">
                  <motion.img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover"
                    whileHover={{ scale: 1.08 }}
                    transition={{ duration: 0.5 }}
                  />
                </div>

                {/* Content */}
                <div className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-display text-xl font-semibold text-foreground group-hover:text-primary transition-colors duration-300">
                      {category.name}
                    </h3>
                    <motion.div
                      className="w-8 h-8 rounded-full bg-primary flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      whileHover={{ scale: 1.1 }}
                    >
                      <ArrowRight className="w-4 h-4 text-primary-foreground" />
                    </motion.div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{category.description}</p>
                  <span className="inline-block px-3 py-1 bg-accent/10 text-accent-foreground text-xs font-medium rounded-full">
                    {category.count}
                  </span>
                </div>

                {/* Hover overlay */}
                <div className="absolute inset-0 border-2 border-transparent group-hover:border-accent rounded-2xl transition-all duration-300 pointer-events-none" />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Categories;
